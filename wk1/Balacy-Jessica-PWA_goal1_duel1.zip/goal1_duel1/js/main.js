/*
Jessica Balacy
05-09-15
Week 1 Assignment: ANALYZE Duel #1 
*/

/**
 * Duel Fight Game - FINISHED
 * Date: 4/09/13

 Assignment 1
 Part 1/3 of series
*/

// self-executing function
(function(){ //run the entire function below

    console.log("FIGHT!!!"); //Print to the console: "FIGHT!!!"

    //player name
    var playerOneName = "Spiderman"; //Declare variable playerOneName, assign value "Spiderman"
    var playerTwoName = "Batman"; //Declare variable playerTwoName, assign value "Batman"

    //player damage
    var player1Damage = 20; //Declare variable player1Damage, assign value "20"
    var player2Damage = 20; //Declare variable player2Damage, assign value "20"

    //player health
    var playerOneHealth = 100; //Declare variable playerOneHealth, assign value "100"
    var playerTwoHealth = 100; //Declare variable playerOneHealth, assign value "100"

    //initiate round
    var round=0; //Declare variable round, assign value of 0 (this determines the round number)

    function fight(){ //Declare function fight
        alert(playerOneName+":"+playerOneHealth+"  *START*  "+playerTwoName+":"+playerTwoHealth); //Notify the user that the game is starting, set both players at max health
        for (var i = 0; i < 10; i++) //repeat this function until it reaches ten
        {
            //random formula is - Math.floor(Math.random() * (max - min) + min);
            var minDamage1 = player1Damage * .5; //set the minimum damage to half of player1Damage
            var minDamage2 = player2Damage * .5; //set the minimum damage to half of player2Damage
            var f1 = Math.floor(Math.random()*(player1Damage-minDamage1)+minDamage1); 
            var f2 = Math.floor(Math.random()*(player2Damage-minDamage2)+minDamage2);

            //inflict damage
            playerOneHealth-=f1; //Change the value of playerOneHealth according to the result of f1
            playerTwoHealth-=f2; //Change the value of playerTwoHealth according to the result of f2

            console.log(playerOneName+": "+playerOneHealth + " " + playerTwoName+":"+playerTwoHealth); //Print the new value of playerOneHealth and PlayerTwoHealth to the console

            //check for victor
            var result = winnerCheck(); //Declare variable result, assign to the function winnerCheck
            console.log(result); //Print to the console: result
            if (result==="no winner") //run this code if the result equals "no winner"
            {
                round++;
                alert(playerOneName+":"+playerOneHealth+"  *ROUND "+round+" OVER"+"*  "+playerTwoName+":"+playerTwoHealth); //Notify the user the health status of playerOneName and PlayerTwoName and the end of the current round

            } else{ //run this code if the result does not equal to "no winner"
                alert(result); //Notify the user of the result of the fight
                break; //terminate the current loop
            };

          };
    };

    function winnerCheck(){ //Declare function winnerCheck
        var result="no winner"; //Declare variable result, assign value "no winner"
        if (playerOneHealth<1 && playerTwoHealth<1) //Check if both player one and player two health levels are less than 1
        {
            result = "You Both Die"; //assign value "You Both Die" to result variable
        } else if(playerOneHealth<1){ //If only player one health level is less than 1, run the code below
            result =playerTwoName+" WINS!!!" //Assign the "WINS!!!" value to the result variable to alert the player that playerTwoName wins
        } else if (playerTwoHealth<1) //If only player two health level is less than 1, run the code below
        {
            result = playerOneName+" WINS!!!" //Assign the "WINS!!!" value to the result variable to alert the player that playerOneName wins
        };
       return result; //end current function and assign the new value to the fight function
    };

    /*******  The program gets started below *******/
    fight(); //Invoke the fight function

})();